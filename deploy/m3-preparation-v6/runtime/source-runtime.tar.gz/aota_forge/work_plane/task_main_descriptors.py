"""Task-main control descriptors — canonical YAML projection (M3/W1).

Single semantic authority is .aota/contracts/operations.yaml via loader.
This module is a thin compatibility projection that deterministically derives
from the canonical source; it does not constitute an independently maintained
hard-coded authority.
TOOL_SCHEMA_SECOND_AUTHORITY=no
"""

from __future__ import annotations

from aota_forge.core.contracts.descriptor import OperationContractDescriptor
# AF #53 M3/W2-R2 (I53-B002): canonical work-item semantic role field owned by
# the durable handoff store; never re-hardcoded as an independent string here.
from aota_forge.work_plane.handoff_store import WORK_ITEM_HANDOFF_ROLE_FIELD


def _load_canonical_descriptor(name: str) -> OperationContractDescriptor:
    from aota_forge.core.contracts.loader import discover_canonical_project_root, load_operation_descriptor_map

    root = discover_canonical_project_root()
    return load_operation_descriptor_map(root)[name]


TASK_MAIN_ACTIVATE_DESCRIPTOR: OperationContractDescriptor = _load_canonical_descriptor("task_main.activate_milestone")
TASK_MAIN_RECOVER_DESCRIPTOR: OperationContractDescriptor = _load_canonical_descriptor("task_main.recover_coordinator")
TASK_MAIN_ADVANCE_DESCRIPTOR: OperationContractDescriptor = _load_canonical_descriptor("task_main.advance_once")
TASK_MAIN_SUBMIT_DESCRIPTOR: OperationContractDescriptor = _load_canonical_descriptor("task_main.submit_work_projection")
TASK_MAIN_CONTEXT_DESCRIPTOR: OperationContractDescriptor = _load_canonical_descriptor("task_main.context")

TASK_MAIN_ACTIVATE_DESCRIPTOR.validate()
TASK_MAIN_RECOVER_DESCRIPTOR.validate()
TASK_MAIN_ADVANCE_DESCRIPTOR.validate()
TASK_MAIN_SUBMIT_DESCRIPTOR.validate()
TASK_MAIN_CONTEXT_DESCRIPTOR.validate()

# W5 (AF #49 M1/W5, I49-B001): canonical normal-path lifecycle descriptors,
# loaded from the same single authority (.aota/contracts/operations.yaml).
HANDOFF_WRITE_DESCRIPTOR: OperationContractDescriptor = _load_canonical_descriptor("handoff.write")
HANDOFF_OPEN_DESCRIPTOR: OperationContractDescriptor = _load_canonical_descriptor("handoff.open")
TASK_START_DESCRIPTOR: OperationContractDescriptor = _load_canonical_descriptor("task.start")
TASK_RETURN_DESCRIPTOR: OperationContractDescriptor = _load_canonical_descriptor("task.return")

HANDOFF_WRITE_DESCRIPTOR.validate()
HANDOFF_OPEN_DESCRIPTOR.validate()
TASK_START_DESCRIPTOR.validate()
TASK_RETURN_DESCRIPTOR.validate()

TASK_MAIN_DESCRIPTORS: tuple[OperationContractDescriptor, ...] = (
    TASK_MAIN_ACTIVATE_DESCRIPTOR,
    TASK_MAIN_RECOVER_DESCRIPTOR,
    TASK_MAIN_ADVANCE_DESCRIPTOR,
    TASK_MAIN_SUBMIT_DESCRIPTOR,
)

# W5 guidance disposition freeze (submit_work_projection stays importable and
# visible for compatibility; it is not the Agent normal path or authority).
SUBMIT_WORK_PROJECTION_REMOVED = False
SUBMIT_WORK_PROJECTION_INTERNAL_COMPATIBILITY_ONLY = True
SUBMIT_WORK_PROJECTION_AGENT_NORMAL_PATH = False
TASK_MAIN_NORMAL_PATH = "authoritative_work_source>handoff.write(work_item)>task.start"

# ---------------------------------------------------------------------------
# M3/W1-R1 model-visible operation guidance (F1); W5 normal-path convergence.
#
# Single schema authority remains .aota/contracts/operations.yaml via loader
# (OPERATION_DESCRIPTOR_AUTHORITY_COUNT=1). This function deterministically
# derives a compact model-usable projection from the canonical descriptors;
# it never hardcodes a second independent schema. Required names/types come
# from descriptor.inputs; type+bound suffixes come from Core constants.
# Usage/example are curated guidance, not schema authority.
#
# W5 (AF #49 M1/W5): normal guidance is now
#   authoritative Work source -> LLM reasoning -> handoff.write(work_item)
#   -> task.start
# task_main.submit_work_projection is retained for compatibility only and is
# explicitly marked as not the Agent normal path (no authority change).
# ---------------------------------------------------------------------------

def _submit_bound_suffix(field_name: str, primitive: str) -> str:
    from aota_forge.work_plane.handoff import (
        MAX_EXPECTATION_LENGTH,
        MAX_EXPECTATIONS_COUNT,
        MAX_OBJECTIVE_LENGTH,
        MAX_SCOPE_LENGTH,
    )

    if primitive == "str":
        if field_name == "work_item_id":
            return "str<=128,correlation not authority"
        if field_name == "objective":
            return f"str<={MAX_OBJECTIVE_LENGTH},executable goal"
        if field_name == "bounded_scope":
            return f"str<={MAX_SCOPE_LENGTH},punctuation ok,text"
        return "str<=4096"
    if primitive == "list":
        if field_name == "validation_expectations":
            return f"list<={MAX_EXPECTATIONS_COUNT}x{MAX_EXPECTATION_LENGTH},evidence"
        if field_name == "semantic_stop_expectations":
            return f"list<={MAX_EXPECTATIONS_COUNT}x{MAX_EXPECTATION_LENGTH},conditions"
        return "list<=256"
    return primitive


_SUBMIT_NOTE = "compatibility only; not agent normal path; cannot bypass Work-source grounding"
_SUBMIT_EXAMPLE = {
    "work_item_id": "W1",
    "objective": "Goal X",
    "bounded_scope": "Implement X in src/x.py",
    "validation_expectations": ["X ok"],
    "semantic_stop_expectations": ["stop if unclear"],
}

# W5 (AF #49 M1/W5): compact normal-path guidance. Names/types come from the
# canonical descriptors; usage and examples are curated guidance. The
# authoritative Work source arrives in activate/recover/advance work_context;
# the model reasons, writes a work_item handoff, then starts the target role.
# submit_work_projection stays compatibility-only and explicitly not the
# Agent normal path. Guidance stays compact to bound the payload; a bootstrap
# over the inline projection bound is delivered as a governed by_ref result.
_NORMAL_PATH_FLOW = "work_context -> reasoning -> handoff.write(mode=work_item) -> task.start"
_HANDOFF_WRITE_NOTE = "normal step 1; mode=work_item; trusted envelope filled by AF"
_HANDOFF_WRITE_EXAMPLE = {
    "mode": "work_item",
    "payload": {"objective": "Goal", "bounded_scope": "Scope"},
}
_TASK_START_NOTE = "normal step 2; AF verifies durable Work-source grounding"
_TASK_START_EXAMPLE = {"role": "coder", "handoff_ref": "<ref from handoff.write>"}

# AF #53 M3/W2-R2 (I53-B002): thin model-visible work-item role grounding.
# The task-main LLM owns the child-role choice; the thin contract makes it
# expressible as payload.work_role at handoff.write and requires exact equality
# with the subsequent task.start.role. Example uses reviewer but the mechanism
# is generic for every permitted child role (coder|analyst|reviewer|
# project-steward) per canonical role policy.
_THIN_NORMAL_PATH_FLOW = (
    "choose child role and Plan Work identity -> handoff.write(mode=work_item, "
    "plan_ref + payload = semantic intent) -> task.start(role=<same role>, handoff_ref=<ref>)"
)
# AF #54 M2/W2: thin affordance ONLY. The canonical detailed handoff procedure
# (semantic fields, work identity rules, typed-error recovery) lives in the
# task-main Role Skill; this note keeps the single first-use invariant that
# prevents the historical role/handoff mismatch, and the example now carries
# the explicit Plan/Work semantic identity the thin grounding requires.
# AF #59 M2: the ordinary task-main session is unbound — the canonical
# plan_ref locator is supplied per operation (it locates the server-side
# authority; it is never authority itself).
_THIN_HANDOFF_WRITE_NOTE = (
    "normal step 1; mode=work_item; supply the canonical plan_ref locator; "
    "payload carries the semantic child role (payload.work_role) and the "
    "authoritative Plan Work identity (work_item_ref, milestone_ref) per the "
    "task-main Skill; payload.work_role MUST equal the subsequent "
    "task.start.role; remaining envelope fields are filled by AF"
)
_PLAN_REF_EXAMPLE = "owner/repo#<plan-number>"
_THIN_HANDOFF_WRITE_EXAMPLE = {
    "mode": "work_item",
    "plan_ref": _PLAN_REF_EXAMPLE,
    "payload": {
        "work_role": "reviewer",
        "work_item_ref": "W1",
        "milestone_ref": "M2",
        "objective": "Review W1 result",
        "bounded_scope": "Read and validate only W1",
    },
}
_THIN_TASK_START_NOTE = (
    "normal step 2; role MUST equal the grounded durable handoff payload.work_role; "
    "supply the same plan_ref locator; missing semantic work_role/work identity "
    "fails closed (typed) before dispatch"
)
_THIN_TASK_START_EXAMPLE = {
    "plan_ref": _PLAN_REF_EXAMPLE,
    "role": "reviewer",
    "handoff_ref": "<ref from handoff.write>",
}

# AF #54 M5/W1-W2: thin primitive contracts for the governed lifecycle
# surfaces. Mechanics only — the semantic procedure (local Governance 2.0 is
# normal; GitHub five-comment reconciliation is compatibility-only) lives
# canonically in the progressive aota-task-main-governance Skill; never
# duplicate it here.
_THIN_GIT_NOTE = (
    "bounded git on the trusted worktree located by the canonical plan_ref "
    "locator (targets never model-supplied); reads eager; "
    "checkpoint/integrate/push are legacy lifecycle compatibility mechanics and "
    "additionally require the current Plan approval and configured trusted "
    "lifecycle authority; FF-only, never force"
)
_THIN_GIT_EXAMPLE = {
    "git.status": {"plan_ref": _PLAN_REF_EXAMPLE},
    "git.diff": {"plan_ref": _PLAN_REF_EXAMPLE, "max_entries": "int?<=100"},
    "git.checkpoint": {"plan_ref": _PLAN_REF_EXAMPLE, "message": "str", "expected_head": "sha40?"},
    "git.integrate": {"plan_ref": _PLAN_REF_EXAMPLE, "expected_old_sha": "sha40 (FF-only CAS)"},
    "git.push": {"plan_ref": _PLAN_REF_EXAMPLE, "expected_remote_sha": "sha40? (never force)"},
}
_THIN_GITHUB_NOTE = (
    "Legacy authority_kind=github_issue compatibility only: Plan-bound GitHub "
    "governance on the Plan Issue located by the canonical "
    "plan_ref locator (repo/owner/issue are NOT model inputs); reads are "
    "card-first with by_ref hydration; mutations are task-main-only and "
    "read-before-write CAS; github.issue.update.body is a WHOLE BODY "
    "REPLACEMENT (never patch/merge/append) — prefer section_marker + "
    "section_content for bounded Plan-state changes and state=closed for "
    "closure; comment roles are task-main semantics"
)
_THIN_GITHUB_EXAMPLE = {
    "github.issue.read": {"plan_ref": _PLAN_REF_EXAMPLE, "view": "card|full?"},
    "github.issue.comments.read": {"plan_ref": _PLAN_REF_EXAMPLE, "max_comments": "int?"},
    "github.issue.update": {
        "plan_ref": _PLAN_REF_EXAMPLE,
        "body?": "str", "section_marker?+section_content?": "str",
        "state?": "open|closed", "expected_updated_at": "str (required)",
    },
    "github.issue.comment.update": {"comment_id": "str", "body": "str", "expected_digest?": "sha64"},
}


def _required_types(descriptor: OperationContractDescriptor) -> dict[str, str]:
    """Deterministic required-name -> type projection from the descriptor."""
    required: dict[str, str] = {}
    for spec in descriptor.inputs:
        if not spec.type.endswith("?"):
            required[spec.name] = spec.type
    return required


def build_task_main_operation_guidance() -> dict[str, dict[str, object]]:
    """Deterministic compact model-visible guidance (W5 normal path first).

    Required names/types are read from the canonical descriptors; usage and
    examples are curated guidance. No second schema authority is created.
    ``task_main.submit_work_projection`` is retained for compatibility and is
    explicitly marked as not the Agent normal path.
    """
    submit_required: dict[str, str] = {}
    for spec in TASK_MAIN_SUBMIT_DESCRIPTOR.inputs:
        submit_required[spec.name] = _submit_bound_suffix(spec.name, spec.type)
    return {
        "normal_path": {
            "flow": _NORMAL_PATH_FLOW,
            "steps": ["handoff.write", "task.start"],
        },
        "handoff.write": {
            "required": _required_types(HANDOFF_WRITE_DESCRIPTOR),
            "note": _HANDOFF_WRITE_NOTE,
            "example": dict(_HANDOFF_WRITE_EXAMPLE),
        },
        "task.start": {
            "required": _required_types(TASK_START_DESCRIPTOR),
            "note": _TASK_START_NOTE,
            "example": dict(_TASK_START_EXAMPLE),
        },
        "task_main.submit_work_projection": {
            "required": submit_required,
            "note": _SUBMIT_NOTE,
            "compatibility_only": True,
            "agent_normal_path": False,
            "example": dict(_SUBMIT_EXAMPLE),
        },
    }


def build_thin_task_main_operation_guidance() -> dict[str, dict[str, object]]:
    """Compact thin-host normal-path guidance (AF #53 M2/W2; #53 M3/W2-R2).

    The thin task-main host exposes only the generic common operations plus
    ``task.start``; no legacy ``task_main.*`` compatibility entry is included,
    because those operations are not part of the thin normal path. Required
    names/types still derive from the same canonical descriptors; no second
    schema authority is created.

    I53-B002 repair: the work_item handoff carries the LLM-chosen child role in
    ``payload.work_role`` (canonical field owned by the durable handoff store)
    and that value MUST equal the subsequent ``task.start.role``. The example
    uses reviewer; the same mechanism supports every permitted child role.
    """
    return {
        "normal_path": {
            "flow": _THIN_NORMAL_PATH_FLOW,
            "steps": ["handoff.write", "task.start"],
        },
        "handoff.write": {
            "required": _required_types(HANDOFF_WRITE_DESCRIPTOR),
            "note": _THIN_HANDOFF_WRITE_NOTE,
            "work_item_role_field": WORK_ITEM_HANDOFF_ROLE_FIELD,
            "role_equality": f"payload.{WORK_ITEM_HANDOFF_ROLE_FIELD} MUST equal task.start.role",
            "example": dict(_THIN_HANDOFF_WRITE_EXAMPLE),
        },
        "task.start": {
            "required": _required_types(TASK_START_DESCRIPTOR),
            "note": _THIN_TASK_START_NOTE,
            "example": dict(_THIN_TASK_START_EXAMPLE),
        },
        "git": {
            "note": _THIN_GIT_NOTE,
            "operations": dict(_THIN_GIT_EXAMPLE),
        },
        "github": {
            "note": _THIN_GITHUB_NOTE,
            "operations": dict(_THIN_GITHUB_EXAMPLE),
        },
        "governance_procedure": (
            "open the aota-task-main-governance progressive Skill before "
            "Project/Plan governance mutation or milestone/plan close. Local "
            "Governance 2.0 is the normal path; the Skill's GitHub branch is "
            "compatibility-only. Never probe mutation schemas against live "
            "authoritative Plan data: read the Skill, then help(operation=...), "
            "then proceed or stop with needs_input."
        ),
    }


def task_main_submit_required_fields() -> tuple[str, ...]:
    """Required field names for submit, derived from canonical descriptor."""
    return tuple(spec.name for spec in TASK_MAIN_SUBMIT_DESCRIPTOR.inputs)
