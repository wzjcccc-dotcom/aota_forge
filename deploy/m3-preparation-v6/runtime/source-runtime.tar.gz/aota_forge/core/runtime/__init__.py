"""Runtime read-only domain."""
