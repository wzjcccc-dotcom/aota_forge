"""Project / workspace resolution domain."""
