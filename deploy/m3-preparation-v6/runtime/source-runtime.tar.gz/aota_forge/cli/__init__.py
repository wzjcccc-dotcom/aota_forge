"""AOTA Forge CLI package."""
