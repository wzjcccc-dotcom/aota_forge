---
name: aota-task-main-governance
description: Task-main Governance workflow — Governance 2.0 local authority is normal, with bounded Governance 1.x GitHub compatibility, read-before-write reconciliation, Milestone close, checkpoint and frontier integration
category: governance
tags: [aota, task-main, governance, plan-issue, managed-comments, git-lifecycle]
---

# AOTA Task-Main Governance (Gov2 normal, Gov1 compatibility)

> `SKILL_IS_AUTHORITY=no`. This is the canonical detailed governance workflow
> for task-main. Governance 2.0 local Project/Plan authority is the normal
> branch; the historical GitHub Issue representation is a bounded compatibility
> branch only. The AF runtime decides authorization; guidance is never authority.
> Tool primitive contracts live in the canonical operation descriptors
> (`role.bootstrap` OPERATION_GUIDANCE / `help` / this file's Tools section).
> Compatibility transport mechanics have one owner here and are not duplicated
> into the Base Skill or SOUL.

```text
GOVERNANCE_SKILL_GOV2_NORMAL=yes
GOVERNANCE_SKILL_GOV1_COMPATIBILITY=yes
GOV1_IS_NORMAL_NEW_PLAN_PATH=no
PROJECT_STEWARD_IS_NORMAL_WORKER=no
PROJECT_STEWARDSHIP_IS_SUBSYSTEM_PLUGIN=yes
DETERMINISTIC_FIRST_STEWARDSHIP=yes
```

## Normal Governance 2.0 path

An ordinary task-main session does not need to be pre-bound. Start with
`role.bootstrap` and `task_main.context(mode=inspect)`; discussion and planning
may remain unbound. When the user chooses governed execution, the existing
`task_main.context(mode=bind)` path accepts semantic Project/optional Plan
selectors, and trusted AF resolution activates the same session. Selectors and
refs locate trusted records; they never mint authority. This Skill remains
guidance, not authority.

For `authority_kind=local_governance`, use this semantic loop:

```text
read current Project / Plan / Milestone context
→ reason the next semantic state change
→ check the user approval or Human Brake
→ invoke governance.project or governance.plan through aota.invoke
→ verify the returned durable result and projection refs
→ continue, request input, or stop
```

The local `plan.md` plus its durable journal/CAS is Plan authority. Project
identity comes from the trusted manifest and Project Registry; `root_ref`,
Cards, ContextRoute, MAP and STATUS are bounded references or projections, not
authority. Do not hand-edit generated MAP/STATUS files and do not create a
second Plan mutation path. Exact inputs and typed errors come from
`help(operation=...)`; this Skill supplies semantic procedure, not a second
operation schema.

Project/Plan modes are intentionally proportional:

- Project `init` establishes trusted registration and initial projections.
- Project `inspect` reads current registration without rewriting projections.
- Project `reconcile` repairs a verified registration/projection drift through the canonical intake.
- Plan `init` materializes an approved local Plan and its initial projections.
- Plan `inspect` reads current local authority and projection state.
- Plan `amend` requires a fresh revision/authority precondition and a semantic decision reference.
- Plan `close` requires the current approval and lifecycle preconditions; verify the durable result.

Never infer project identity from a filesystem path, session directory, profile,
or search result. Ambiguous identity, stale revision/authority, missing approval,
or unknown durable outcome is `needs_input`/blocked, not a reason to probe or
retry.

## Why task-main owns this now

`TASK_MAIN_TEMPORARY_STEWARDSHIP=no`
`PROJECT_STEWARD_NEW_NORMAL_DELEGATION=no`
`PROJECT_STEWARD_LEGACY_COMPATIBILITY=yes`

You do NOT delegate ordinary Governance 2.0 reconciliation to a
project-steward child. You read the authoritative state, decide the semantic
update, and use the canonical AF intake. The project-steward role/Skill remains
loadable only as a compatibility execution vehicle for genuine semantic
residuals; deterministic stewardship is the normal subsystem boundary.
Never delegate governance to a project-steward child in the normal path.
`AOTA_TASK_LIFECYCLE_REINTRODUCED=no` — the historical lifecycle Skill stays
outside your normal path.

## Legacy Governance 1.x compatibility model

The following branch applies only when the trusted authority explicitly has
`authority_kind=github_issue`. It is not the normal new-Plan path and it does
not redefine Portable Plan semantics. A GitHub Issue body and its managed
comments are adapter-specific legacy evidence; use the current Gov2 workflow
for local authority.

## Legacy authoritative model (compatibility only)

1. **The Plan GitHub Issue body is the normative Plan authority.**
   An ordinary task-main session is **unbound**: it carries no Plan or
   session binding. Every Plan-bound governance/Git operation supplies the
   canonical `plan_ref` (`owner/repo#number`) in its arguments. The ref
   locates the current server-side authority (live Plan + trusted project +
   lifecycle authority); a ref is an authority **locator**, never authority
   itself, and a session/directory/profile grants nothing. If the user gives
   only a bare issue number (`#39`) and no trusted unique `plan_ref`, stop and
   ask for `owner/repo#number` — never explore `host.status` /
   `runtime.status`, the workspace, the profile, session metadata or a project
   search to infer the repository.
2. **Exactly five canonical managed comments** carry the living governance
   state. Each managed comment's body carries the marker
   `COMMENT_ROLE=<role>` as its first line, where `<role>` is one of:
   - `milestone_progress_index` — current milestone/work/status truth
   - `development_notes` — currently-valid engineering truth per work item
   - `defect_register` — open/closed plan defects (`I<issue>-B<nnn>` ids)
   - `plan_appendix` — evidence references (smoke/observation artifacts)
   - `decision_change_log` — material decisions only (`D<nn>` entries)
   YOU decide which comment is which by reading comment content. The Control
   Plane never assigns semantic names — `github.issue.comments.read` returns
   raw facts (`comment_id`, `author`, `updated_at`, bounded body). If a role
   is missing or duplicated, that is a governance defect: record it in the
   defect register and reconcile deliberately; never guess silently.

## Core loop: read-before-write, always

Before ANY governed mutation:

1. `github.issue.read {plan_ref}` (card view) — Plan body truth
   (`state`, `updated_at`, `body_digest`).
2. `github.issue.comments.read {plan_ref}` — current managed comments
   (`comment_id`, `updated_at`, `body`, `body_digest`). Hydrate a truncated
   body through the attached `output_ref` claims (`result.hydrate`) before
   rewriting that comment wholesale.
3. Compose the new content from the freshest read + your semantic judgment.
4. Write with the CAS token from the read:
   - comment update: `github.issue.comment.update {plan_ref, comment_id,
     body, expected_digest}` — `expected_digest` is the `body_digest` you read;
   - issue body/state update: `github.issue.update {plan_ref, …,
     expected_updated_at}` with `body`, or a bounded
     `section_marker`/`section_content` upsert, or `state` for Plan closure.
5. A `GITHUB_CAS_CONFLICT` means someone (or something) moved the state
   after your read. Re-read, re-reason, re-apply. Never blind-retry the old
   write, and never weaken the CAS to "make progress".

Stale snapshots cannot silently overwrite newer authoritative content;
identical content is an idempotent no-op (`already_applied=true`).

This is a mutation discipline, not a re-read-per-step rule: an already-open
Skill, a prior read result and its digest, or a prior search/card whose refs
are still valid stay usable (`KNOWN_CONTEXT_REUSE_FIRST=yes`). Take a fresh
authoritative read when a mutation/CAS needs current truth; do not repeat
`skill.open` / the same search / the same hydrate without a real freshness
reason.

## Progressive Governance context (Governance 2.0, card-first)

```text
CONTEXT_ROUTE_IS_AUTHORITY=no
GOVERNANCE_CARD_IS_AUTHORITY=no
CARD_FIRST=yes
SEMANTIC_SECTION_FIRST=yes
FULL_PLAN_EAGER_HYDRATION=no
SEMANTIC_REUSE_BYPASSES_AUTHORITY_CHECK=no
```

When the runtime exposes compact Governance Cards (Project / Plan / Milestone /
Architecture / Progress) and a Context Route in bootstrap, treat them as
derived navigation only: they summarize current truth and point at deeper
refs; they never authorize and never replace the authoritative read. Use them
to choose what to retrieve, then read the exact ref.

Retrieve the authoritative Plan body section-first: locate the semantic
section carrying the fact and read/write that bounded section
(`section_marker` + `section_content` upsert) instead of traversing by blind
offsets. Unknown Plan/AGENTS content starts from the card or its bounded
policy ref; do not eagerly hydrate the whole Plan or the whole AGENTS policy
set.

Semantic reuse only means "keep reasoning from still-valid context". It never
satisfies a mutation precondition: before any governed write you still re-read
the exact authoritative state and use the CAS token from that read
(`CONTROL_COMMENT_READ_BEFORE_WRITE=yes`, `SEMANTIC_REUSE_BYPASSES_AUTHORITY_CHECK=no`).

## Destructive body semantics (M2/W3 — explicit)

```text
github.issue.update.body            = WHOLE BODY REPLACEMENT
  not a patch, not a merge, not an append. The candidate replaces the
  complete normative Plan body. For a recognized Portable Plan Issue the
  candidate MUST be a complete structurally valid Portable Plan preserving
  the Plan identity (PROJECT_ID + kind); an invalid/incomplete candidate is
  rejected with INVALID_INPUT / PLAN_BODY_INVALID BEFORE any GitHub mutation.
  Whole-body replacement is only for genuinely necessary full rewrites.

github.issue.update.section_marker + section_content
  = BOUNDED_SECTION_UPSERT (preferred for bounded Plan-state changes)

github.issue.update.state
  = open|closed (Plan closure; not a body rewrite)

expected_updated_at                 = CAS precondition (required)
```

Default guidance: use `section_marker` + `section_content` for bounded
Plan-state changes; use `state=closed` for closure; send a whole body only
when the complete replacement genuinely is the Plan.

## No live mutation probing (M2/W3)

Never probe mutation schemas against live authoritative Plan data. If an
operation shape is unclear:

1. read the relevant Skill (this file / the base Skill),
2. call `help(operation=...)` for the exact canonical mechanics,
3. if still unclear, stop with `needs_input`.

Do not send synthetic live mutation payloads to learn semantics. A failed
experiment can corrupt normative Plan authority; there is no "test write"
against the real Plan.

## Milestone procedures

### Entry (bounded refinement)
- Verify the milestone is already materialized in the existing Plan; extend
  the current Plan rather than inventing successor issues.
- Refine the milestone into ordered Work Items with explicit DAG +
  acceptance. Record the refinement in `milestone_progress_index`; a
  material change of direction also earns a `decision_change_log` entry.
- Record the user's approval truth verbatim-semantic (e.g.
  `M5_USER_APPROVAL_SATISFIED=yes`) with its basis. You NEVER mint approval
  yourself; absent approval means stop at the user gate.

### During
- Keep `milestone_progress_index` current: `CURRENT_WORK_ITEM`, statuses,
  approval facts, base SHA/entry state.
- Keep `development_notes` as the currently-valid engineering truth per Work
  Item (what was built, seams touched, validation evidence) — replace
  superseded statements, keep it short.
- Register real defects with stable ids (`I<plan-number>-B<nnn>`) in the
  defect register; close them with the repair evidence reference.
- Put run/artifact references (smoke summaries, observation cards, session
  ids) in `plan_appendix` — references, not transcripts.
- Log only MATERIAL decisions (architecture, disposition changes, approval
  events) in `decision_change_log`. No routine operational noise.

### Close
1. Integrated review outcome recorded (e.g. `M5_RV1=PASS`).
2. Known-good checkpoint: commit the accepted worktree frontier
   (`git.checkpoint {plan_ref, message, expected_head?}`), then FF-only
   integration (`git.integrate {plan_ref, expected_old_sha}` with the
   `expected_old_sha` you observed via `git.status`), then sync the trusted
   remote (`git.push {plan_ref, expected_remote_sha?}`) when governance
   requires local == remote. Verify `LOCAL_MAIN == ORIGIN_MAIN ==
   <checkpoint sha>` from operation results; never force.
3. Update the progress index (`*_STATUS=completed`, `*_ACCEPTED=yes`,
   `KNOWN_GOOD_CHECKPOINT=<sha>`), development notes final state, appendix
   with the checkpoint/integration evidence.
4. Only for PLAN closure: update the issue body status section
   (`github.issue.update` with `section_marker`/`section_content`) and, when
   the Plan is genuinely complete, `state=closed`.
5. Checkpoint reconciliation at any session start: compare the recorded
   known-good SHA against `git.status` reality; a mismatch is a defect or a
   drift signal, not something to paper over.

## Git lifecycle stance

You own the semantic decisions: *this Work is accepted*, *a checkpoint is
appropriate now*, *the Milestone should integrate*. The Control Plane
mechanically enforces: your authority, the trusted worktree located by
`plan_ref`, expected-old CAS, FF-only, the configured remote/ref. The
lifecycle operations additionally require the **current** Milestone approval
server-side; `MILESTONE_APPROVAL_REQUIRED` is the user gate — stop, report,
never bypass. `AUTHORITY_DENIED` means "not configured/not yours", never a
puzzle to bypass. Do not create meaningless commits to exercise the tools;
commit accepted work at real decision points. Destructive verbs (reset
--hard, clean, force push, rebase, arbitrary argv) do not exist here — do not
seek them via restricted shell (`GIT_VIA_RESTRICTED_SHELL=no`,
`GITHUB_VIA_RESTRICTED_SHELL=no`; `aota-restricted-shell` is residual
fallback only).

## Tools (thin primitive contract — mechanics canonical here for the transition; descriptions stay in OPERATION_GUIDANCE / help)

```text
github.issue.read            {plan_ref, view? card|full}
github.issue.comments.read   {plan_ref, max_comments?}
github.issue.update          {plan_ref, body? | section_marker+section_content? | state? , expected_updated_at}
github.issue.comment.update  {plan_ref, comment_id, body, expected_digest?}
git.status / git.diff        {plan_ref} (bounded reads of the trusted worktree)
git.checkpoint               {plan_ref, message, expected_head?}
git.integrate                {plan_ref, expected_old_sha}     (FF-only, CAS)
git.push                     {plan_ref, expected_remote_sha?} (FF-only, never force)
```

All through `aota.invoke` — the only Agent-facing AF MCP tool. Large results
arrive `by_ref`; hydrate via the attached claims. For the exact current
canonical arguments call `help(operation=...)`.

## Stop conditions

- Missing user approval for the next construction phase → stop at the gate
  and report exactly what approval is needed.
- Governance state you cannot reconcile confidently from reads → re-read,
  then register a defect; do not mutate speculatively.
- `AUTHORITY_DENIED` is a boundary, not a puzzle: it never licenses an
  alternative transport (raw gh, generic API, shell) for the same goal.
